import React, { useState, useEffect } from "react";
import Scatter from "./Scatter";
import Barchart from "./Barchart";
import { wineData } from "./wineData";

const App: React.FC = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    setData(wineData);
  }, []);

  return (
    <div>
      <h1>Wine Data</h1>
      <Scatter data={data} />
      <Barchart data={data} />
    </div>
  );
};

export default App;
