import React from "react";
import ReactEcharts from "echarts-for-react";

interface ScatterPlotProps {
  data: { alcohol: number; color_intensity: number; hue: number }[];
}

const Scatter: React.FC<ScatterPlotProps> = ({ data }) => {
  const getOption = () => {
    const xAxisData = data.map((d) => d.color_intensity);
    const yAxisData = data.map((d) => d.hue);

    return {
      xAxis: {
        type: "value",
        name: "Color Intensity",
        data: xAxisData
      },
      yAxis: {
        type: "value",
        name: "Hue",
        data: yAxisData
      },
      series: [
        {
          type: "scatter",
          data: data.map((d) => [d.color_intensity, d.hue])
        }
      ]
    };
  };

  return <ReactEcharts option={getOption()} />;
};

export default Scatter;
