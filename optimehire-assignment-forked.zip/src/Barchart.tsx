import React from "react";
import ReactEcharts from "echarts-for-react";

interface BarChartProps {
  data: {
    alcohol: number;
    malic_acid: number;
  }[];
}

const Barchart: React.FC<BarChartProps> = ({ data }) => {
  const getOption = () => {
    const uniqueAlcohols = Array.from(
      new Set(data.map((d) => d.alcohol))
    ).sort();

    const yAxisData = uniqueAlcohols.map((alcohol) => {
      const malicAcids = data
        .filter((d) => d.alcohol === alcohol)
        .map((d) => d.malic_acid);

      const averageMalicAcid =
        malicAcids.reduce((sum, malicAcid) => sum + malicAcid, 0) /
        malicAcids.length;

      return averageMalicAcid;
    });

    return {
      xAxis: {
        type: "category",
        name: "Alcohol",
        data: uniqueAlcohols
      },
      yAxis: {
        type: "value",
        name: "Average Malic Acid"
      },
      series: [
        {
          type: "bar",
          data: yAxisData
        }
      ]
    };
  };

  return <ReactEcharts option={getOption()} />;
};

export default Barchart;
